window._config = {
    cognito: {
        userPoolId: 'us-east-1_CxwfmVV6o', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '7hqkvhir76sue3fbhe259k09cf', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://ah93yq8y22.execute-api.us-east-1.amazonaws.com/Dev' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};







